package com.example.snackbardemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class qrgenerador extends AppCompatActivity {
Button but1;
EditText ed1;
ImageView img1;
BarcodeEncoder bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrgenerador);
        but1=findViewById(R.id.btn3);
        ed1=findViewById(R.id.edtx1);
        img1=findViewById(R.id.imgqr);
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                            Bitmap bitmap = barcodeEncoder.encodeBitmap(ed1.getText().toString(),
                                    BarcodeFormat.QR_CODE, 400, 400)
                                    ;
                 img1.setImageBitmap(bitmap);


                  /* ImageView imageViewQrCode = (ImageView) findViewById(R.id.imgqr);
                       imageViewQrCode.setImageBitmap(bitmap);
                       */

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
